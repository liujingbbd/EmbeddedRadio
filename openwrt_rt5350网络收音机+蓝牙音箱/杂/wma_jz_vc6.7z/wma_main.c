
#include "wma_avcodec.h"
#include "wma_avio.h"

AVCodec *codec=NULL;
AVCodecContext *actx=NULL;

char *iPCMBuffer=NULL;

void get_wav_header(ByteIOContext *pb, AVCodecContext *codec, int size);

void InitDecoder()
{
	int  ret;
	int  exten_len=28;
	char exten_byte[28]={0x61, 0x01, 0x02, 0x00,  0x00, 0x7D, 0x00, 0x00,   0xA0, 0x0F, 0x00, 0x00,  0x00, 0x06, 0x10, 0x00,  0x0A, 0x00, 0x00, 0x88,  0x00, 0x00, 0x17, 0x00,   0x00, 0x1E, 0x00, 0x00};
	
	ByteIOContext pb;

	avcodec_init();
	avcodec_register_all();
	
	actx = avcodec_alloc_context();
	
	pb.buffer = (unsigned char*)exten_byte;
	pb.buffer_size = exten_len;
	pb.buf_end = pb.buffer + pb.buffer_size;	
	pb.buf_ptr = pb.buffer;
	
	get_wav_header(&pb, actx, exten_len);
	
	codec = &wmav2_decoder; // avcodec_find_decoder(CODEC_ID_WMAV2);
	if (!codec)
		return ;
	
	ret = avcodec_open(actx, codec);

	iPCMBuffer = malloc(70*1024);
}

int Decoder(unsigned char* wmabuf, int bufsz)
{
	int data_size = 4096;

	avcodec_decode_audio(actx, (int16_t*)iPCMBuffer, &data_size, (uint8_t*)wmabuf, bufsz);
	
	return data_size;	
}

void UninitDecoder()
{	
	if(codec)
	{
		avcodec_close(actx); 
		codec = NULL;
	}

	free(iPCMBuffer);
}

void main()
{
	int  i=0;
	int  size;
	char buf[1536];

	FILE *fp = fopen("wma.dat", "rb");
	FILE *fp2 = fopen("dat.pcm", "wb");

	InitDecoder();

	for(i=0; i<10; i++)
	{
		fread(buf, 1, 1536, fp);

		size=Decoder(buf, 1536);

		fwrite(iPCMBuffer, 1, size, fp2);
	}

	UninitDecoder();

	fclose(fp);
	fclose(fp2);	
}
