/********************************************************************
 *                                                                  *
 * THIS FILE IS PART OF THE OggVorbis 'TREMOR' CODEC SOURCE CODE.   *
 *                                                                  *
 * USE, DISTRIBUTION AND REPRODUCTION OF THIS LIBRARY SOURCE IS     *
 * GOVERNED BY A BSD-STYLE SOURCE LICENSE INCLUDED WITH THIS SOURCE *
 * IN 'COPYING'. PLEASE READ THESE TERMS BEFORE DISTRIBUTING.       *
 *                                                                  *
 * THE OggVorbis 'TREMOR' SOURCE CODE IS (C) COPYRIGHT 1994-2002    *
 * BY THE Xiph.Org FOUNDATION http://www.xiph.org/                  *
 *                                                                  *
 ********************************************************************

 function: modified discrete cosine transform prototypes

 ********************************************************************/

#ifndef _OGG_mdct2_H_
#define _OGG_mdct2_H_

#define 	IBSS_ATTR
#define 	ICONST_ATTR
#define 	ICODE_ATTR
#define 	VLCBITS   7
#define 	VLCMAX   ((22+VLCBITS-1)/VLCBITS)
#define 	EXPVLCBITS   7
#define 	EXPMAX   ((19+EXPVLCBITS-1)/EXPVLCBITS)
#define 	HGAINVLCBITS   9
#define 	HGAINMAX   ((13+HGAINVLCBITS-1)/HGAINVLCBITS)
#define 	VLCBUF1SIZE   4598
#define 	VLCBUF2SIZE   3574
#define 	VLCBUF3SIZE   360
#define 	VLCBUF4SIZE   540


typedef short ogg_int16_t;
typedef int ogg_int32_t;
typedef unsigned int ogg_uint32_t;
typedef long long ogg_int64_t;


#ifdef _LOW_ACCURACY_
#  define X(n) (((((n)>>22)+1)>>1) - ((((n)>>22)+1)>>9))
#  define LOOKUP_T const unsigned char
#else
#  define X(n) (n)
#  define LOOKUP_T const ogg_int32_t
#endif

//#include <codecs.h>
#include "asm_arm.h"
#include "asm_mcf5249.h"
#include "misc.h"

#ifndef ICONST_ATTR_TREMOR_WINDOW
#define ICONST_ATTR_TREMOR_WINDOW ICONST_ATTR
#endif

#ifndef ICODE_ATTR_TREMOR_MDCT
#define ICODE_ATTR_TREMOR_MDCT ICODE_ATTR
#endif

#ifndef ICODE_ATTR_TREMOR_NOT_MDCT
#define ICODE_ATTR_TREMOR_NOT_MDCT ICODE_ATTR
#endif



#define DATA_TYPE ogg_int32_t
#define REG_TYPE  register ogg_int32_t

#ifdef _LOW_ACCURACY_
#define cPI3_8 (0x0062)
#define cPI2_8 (0x00b5)
#define cPI1_8 (0x00ed)
#else
#define cPI3_8 (0x30fbc54d)
#define cPI2_8 (0x5a82799a)
#define cPI1_8 (0x7641af3d)
#endif

#include "fft.h"

typedef struct MDCTContext
{
    int n;  /* size of MDCT (i.e. number of input data * 2) */
    int nbits; /* n = 2^nbits */
    /* pre/post rotation tables */
    FFTContext fft;
}
MDCTContext;

extern void mdct_backward(int n, ogg_int32_t *in, DATA_TYPE *out);

#endif












