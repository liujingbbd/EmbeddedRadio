
#include "wma_avcodec.h"

#include <limits.h>
#include <float.h>

void *av_mallocz(unsigned int size)
{
    void *ptr;

    ptr = av_malloc(size);
    if (!ptr)
        return NULL;
    memset(ptr, 0, size);
    return ptr;
}

void *av_fast_realloc(void *ptr, unsigned int *size, unsigned int min_size)
{
    if (min_size <  *size)
        return ptr;

    *size = FFMAX(17 *min_size / 16+32, min_size);

    return av_realloc(ptr,  *size);
}

static unsigned int last_static = 0;
static unsigned int allocated_static = 0;
static void **array_static = NULL;

void *av_mallocz_static(unsigned int size)
{
    void *ptr = av_mallocz(size);

    if (ptr)
    {
        array_static = av_fast_realloc(array_static, &allocated_static, sizeof(void*)*(last_static + 1));
        if (!array_static)
            return NULL;
        array_static[last_static++] = ptr;
    }

    return ptr;
}

void *av_realloc_static(void *ptr, unsigned int size)
{
    int i;
    if (!ptr)
        return av_mallocz_static(size);

    for (i = 0; i < last_static; i++)
    {
        if (array_static[i] == ptr)
        {
            array_static[i] = av_realloc(array_static[i], size);
            return array_static[i];
        }
    }
    return NULL;
}

void av_free_static(void)
{
    while (last_static)
    {
        av_freep(&array_static[--last_static]);
    }
    av_freep(&array_static);
}

void av_freep(void *arg)
{
    void **ptr = (void **)arg;
    av_free(*ptr);
    *ptr = NULL;
}

AVCodec *first_avcodec = NULL;

void register_avcodec(AVCodec *format)
{
    AVCodec **p;
    p = &first_avcodec;
    while (*p != NULL)
        p = &(*p)->next;
    *p = format;
    format->next = NULL;
}

AVCodecContext *avcodec_alloc_context(void)
{
    AVCodecContext *avctx = av_malloc(sizeof(AVCodecContext));

    if (avctx == NULL)
        return NULL;
   
	memset(avctx, 0, sizeof(AVCodecContext));

    avctx->bit_rate = 800 * 1000;

    avctx->flags2 = 0;

    return avctx;
}

int avcodec_open(AVCodecContext *avctx, AVCodec *codec)
{
    int ret =  - 1;  

    if (avctx->codec)
        goto end;

    if (codec->priv_data_size > 0)
    {
        avctx->priv_data = av_mallocz(codec->priv_data_size);
        if (!avctx->priv_data)
            goto end;
    }
    else
    {
        avctx->priv_data = NULL;
    }

    avctx->codec = codec;
    avctx->codec_id = codec->id;
    avctx->frame_number = 0;
    ret = avctx->codec->init(avctx);
    if (ret < 0)
    {
        av_freep(&avctx->priv_data);
        avctx->codec = NULL;
        goto end;
    }
    ret = 0;
end: 
    return ret;
}

/* decode an audio frame. return -1 if error, otherwise return the
 *number of bytes used. If no frame could be decompressed,
 *frame_size_ptr is zero. Otherwise, it is the decompressed frame
 *size in BYTES. */
int avcodec_decode_audio(AVCodecContext *avctx, int16_t *samples, int *frame_size_ptr, uint8_t *buf, int buf_size)
{
    int ret=0;

    *frame_size_ptr = 0;
    if (buf_size)
    {
        ret = avctx->codec->decode(avctx, samples, frame_size_ptr, buf, buf_size);
        avctx->frame_number++;
    }

    return ret;
}

int avcodec_close(AVCodecContext *avctx)
{  
    if (avctx->codec->close)
        avctx->codec->close(avctx);

    av_freep(&avctx->priv_data);
    avctx->codec = NULL;
    return 0;
}

AVCodec *avcodec_find_decoder(enum CodecID id)
{
    AVCodec *p;
    p = first_avcodec;
    while (p)
    {
        if (p->decode != NULL && p->id == id)
            return p;
        p = p->next;
    }
	return NULL;
}

void avcodec_init(void)
{

}

void avcodec_flush_buffers(AVCodecContext *avctx)
{
    if (avctx->codec->flush)
        avctx->codec->flush(avctx);
}
