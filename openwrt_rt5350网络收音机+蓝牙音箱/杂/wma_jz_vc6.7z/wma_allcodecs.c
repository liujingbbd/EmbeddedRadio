
#include "wma_avcodec.h"

void avcodec_register_all(void)
{
    register_avcodec(&wmav1_decoder);
    register_avcodec(&wmav2_decoder);
}

