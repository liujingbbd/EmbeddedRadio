
#include "wma_avcodec.h"
#include "wma_avio.h"

#define FF_INPUT_BUFFER_PADDING_SIZE 8

typedef struct CodecTag
{
    int id;
    unsigned int tag;
    unsigned int invalid_asf;
} CodecTag;

const CodecTag codec_wav_tags[] = {
    { CODEC_ID_WMAV1, 0x160 },
    { CODEC_ID_WMAV2, 0x161 },
    { 0, 0 },
};

enum CodecID codec_get_id(const CodecTag *tags, unsigned int tag)
{
    while (tags->id != CODEC_ID_NONE)
    {
        if (toupper((tag >> 0) &0xFF) == toupper((tags->tag >> 0) &0xFF) && toupper((tag >> 8) &0xFF) == toupper((tags->tag >> 8) &0xFF) && toupper((tag >> 16) &0xFF) == toupper((tags->tag >> 16) &0xFF) && toupper((tag >> 24) &0xFF) == toupper((tags->tag >> 24) &0xFF))
            return tags->id;
        tags++;
    } 
	
	return CODEC_ID_NONE;
}

int wav_codec_get_id(unsigned int tag, int bps)
{
    int id; bps;
    id = codec_get_id(codec_wav_tags, tag);
    if (id <= 0)
        return id;

    return id;
}

unsigned int get_le16(ByteIOContext *s)
{
    unsigned int val;
    val = get_byte(s);
    val |= get_byte(s) << 8;
    return val;
}

unsigned int get_le32(ByteIOContext *s)
{
    unsigned int val;
    val = get_le16(s);
    val |= get_le16(s) << 16;
    return val;
}

/* We could be given one of the three possible structures here:
 * WAVEFORMAT, PCMWAVEFORMAT or WAVEFORMATEX. Each structure
 * is an expansion of the previous one with the fields added
 * at the bottom. PCMWAVEFORMAT adds 'WORD wBitsPerSample' and
 * WAVEFORMATEX adds 'WORD  cbSize' and basically makes itself
 * an openended structure.
 */
void get_wav_header(ByteIOContext *pb, AVCodecContext *codec, int size)
{
    int id;

    id = get_le16(pb);
//    codec->codec_type = CODEC_TYPE_AUDIO;
    codec->codec_tag = id;
    codec->channels = get_le16(pb);
    codec->sample_rate = get_le32(pb);
    codec->bit_rate = get_le32(pb) *8;
    codec->block_align = get_le16(pb);
    if (size == 14)
    {
         /* We're dealing with plain vanilla WAVEFORMAT */
        codec->bits_per_sample = 8;
    }
    else
        codec->bits_per_sample = get_le16(pb);

    codec->codec_id = wav_codec_get_id(id, codec->bits_per_sample);

    if (size > 16)
    {
         /* We're obviously dealing with WAVEFORMATEX */
        codec->extradata_size = get_le16(pb);
        if (codec->extradata_size > 0)
        {
            if (codec->extradata_size > size - 18)
                codec->extradata_size = size - 18;
            codec->extradata = av_mallocz(codec->extradata_size + FF_INPUT_BUFFER_PADDING_SIZE);
            get_buffer(pb, codec->extradata, codec->extradata_size);
        }
        else
            codec->extradata_size = 0;

        /* It is possible for the chunk to contain garbage at the end */
//        if (size - codec->extradata_size - 18 > 0)
//            url_fskip(pb, size - codec->extradata_size - 18);
    }
}

