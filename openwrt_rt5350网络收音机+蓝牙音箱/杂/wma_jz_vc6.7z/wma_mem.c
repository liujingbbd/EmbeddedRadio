
#include "wma_avcodec.h"

#include <stdlib.h>

#define INT_MAX	2147483647

void *av_malloc(unsigned int size)
{
    void *ptr;
    if (size > INT_MAX)
        return NULL;
    ptr = malloc(size);

    return ptr;
}

void *av_realloc(void *ptr, unsigned int size)
{
    if (size > INT_MAX)
        return NULL;

    return realloc(ptr, size);
}

void av_free(void *ptr)
{
    if (ptr)
        free(ptr);
}
