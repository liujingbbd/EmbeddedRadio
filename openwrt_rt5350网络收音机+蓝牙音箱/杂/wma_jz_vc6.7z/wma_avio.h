
#ifndef AVIO_H
#define AVIO_H

#ifdef __cplusplus
extern "C" {
#endif

#include "wma_common.h"

//typedef int64_t offset_t;

typedef struct ByteIOContext
{
    unsigned char *buffer;
    int buffer_size;
    unsigned char *buf_ptr,  *buf_end;
//    void *opaque;
//    int(*read_packet)(void *opaque, uint8_t *buf, int buf_size);
//    offset_t(*seek)(void *opaque, offset_t offset, int whence);
//    offset_t pos; /* position in the file of the current buffer */
//    int eof_reached; /* true if eof reached */
//    int write_flag; /* true if open for writing */
//    int error; ///< contains the error code or 0 if no error happened
} ByteIOContext;

int get_buffer(ByteIOContext *s, unsigned char *buf, int size);
int get_byte(ByteIOContext *s);

#ifdef __cplusplus
}
#endif

#endif
